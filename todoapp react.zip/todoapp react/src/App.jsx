import { useState } from "react";
import "./App.css";

function App() {
  const [currentToDo, setCurrentToDo] = useState("");
  const [todo, setToDo] = useState([]);

  const addToDo = () => {
    setToDo([...todo, currentToDo]);
    setCurrentToDo("");
    console.log(todo);
  };

  const removeToDo = (id) => {
    setToDo([
      ...todo.slice(0, id),
      ...todo.slice(id + 1, todo.length)
    ]);
  }

  return (
    <>
      <div className="app_content">
        <div className="header">
          <div className="container">
            <div>
              <h2 className="title">My To Do List</h2>
              <div className="subtitle">You have 3 tasks on the list</div>
              <div className="row mar-top-20 addbox">
                <input
                  type="text"
                  name=""
                  id="add_input"
                  className="add_input"
                  value={currentToDo}
                  onChange={(e) => setCurrentToDo(e.target.value)}
                />
                <button
                  type="button"
                  className="add_button"
                  id="add_button"
                  onClick={() => addToDo()}
                >
                  ADD
                </button>
              </div>
            </div>
          </div>
        </div>
        <div className="content">
          <div className="container" id="todo_list">
            {todo.map((todoitem,index) => (
              <div className="toto_box mar-bottom-20" id={"todo-item-"+index} key={index}>
                <div className="row">
                  <div className="todo_text">{todoitem}</div>
                  <div className="todo_action" onClick={() => removeToDo(index)}>
                    <i className="fa-regular fa-trash-can"></i>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
